(() => {
  const MEDIA_HOSTS = [
    "youtube.com",
    "youtu.be",
    "vimeo.com",
    "twitch.tv",
    "soundcloud.com",
    "tiktok.com",
    "instagram.com",
    "facebook.com",
    "fb.watch",
    "x.com",
    "twitter.com",
    "reddit.com",
    "dailymotion.com",
    "bilibili.com",
    "rumble.com",
    "odysee.com",
    "kick.com",
  ];

  let enabled = true;
  let activeVideo = null;
  let hideTimer = null;
  let hostEl = null;
  let pillBtn = null;

  function isKnownMediaSite() {
    const host = location.hostname.toLowerCase();
    return MEDIA_HOSTS.some((mh) => host === mh || host.endsWith("." + mh));
  }

  function resolveCaptureUrl(video) {
    if (isKnownMediaSite()) {
      return location.href;
    }
    const src = video?.currentSrc || video?.src || "";
    if (src.startsWith("http://") || src.startsWith("https://")) {
      return src;
    }
    return location.href;
  }

  function ensureOverlay() {
    if (hostEl) return;
    hostEl = document.createElement("div");
    hostEl.id = "fluxdm-video-overlay-host";
    hostEl.style.cssText =
      "position:fixed;z-index:2147483647;display:none;pointer-events:auto;";
    const shadow = hostEl.attachShadow({ mode: "closed" });

    const style = document.createElement("style");
    style.textContent = `
      .fluxdm-pill {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 12px;
        border-radius: 9999px;
        border: 1px solid rgba(99, 102, 241, 0.65);
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.94), rgba(30, 27, 75, 0.94));
        color: #f8fafc;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45);
        backdrop-filter: blur(8px);
        transition: transform 0.15s ease, box-shadow 0.15s ease;
      }
      .fluxdm-pill:hover {
        transform: translateY(-1px);
        box-shadow: 0 10px 28px rgba(79, 70, 229, 0.45);
      }
      .fluxdm-dot {
        width: 8px;
        height: 8px;
        border-radius: 9999px;
        background: #22d3ee;
      }
    `;

    pillBtn = document.createElement("button");
    pillBtn.type = "button";
    pillBtn.className = "fluxdm-pill";
    pillBtn.innerHTML = `<span class="fluxdm-dot"></span><span>Download with FluxDM</span>`;

    pillBtn.addEventListener("mouseenter", () => {
      if (hideTimer) {
        clearTimeout(hideTimer);
        hideTimer = null;
      }
    });

    pillBtn.addEventListener("mouseleave", () => {
      scheduleHide();
    });

    pillBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const targetUrl = resolveCaptureUrl(activeVideo);
      const labelSpan = pillBtn.querySelector("span:last-child");
      if (labelSpan) labelSpan.textContent = "Sent to FluxDM!";
      chrome.runtime.sendMessage(
        {
          type: "CAPTURE_VIDEO",
          url: targetUrl,
          referrer: location.href,
          kind: "media",
        },
        () => {
          setTimeout(() => {
            if (labelSpan) labelSpan.textContent = "Download with FluxDM";
          }, 1600);
        }
      );
    });

    shadow.appendChild(style);
    shadow.appendChild(pillBtn);
    document.documentElement.appendChild(hostEl);
  }

  function positionOverlay(video) {
    if (!hostEl || !video) return;
    const rect = video.getBoundingClientRect();
    if (rect.width < 200 || rect.height < 120) {
      hostEl.style.display = "none";
      return;
    }
    const top = Math.max(8, rect.top + 10);
    const right = Math.max(8, window.innerWidth - rect.right + 10);
    hostEl.style.top = `${top}px`;
    hostEl.style.right = `${right}px`;
    hostEl.style.left = "auto";
    hostEl.style.display = "block";
  }

  function showForVideo(video) {
    if (!enabled) return;
    if (hideTimer) {
      clearTimeout(hideTimer);
      hideTimer = null;
    }
    ensureOverlay();
    activeVideo = video;
    positionOverlay(video);
  }

  function scheduleHide() {
    if (hideTimer) clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      if (hostEl) hostEl.style.display = "none";
      activeVideo = null;
    }, 350);
  }

  function attachToVideo(video) {
    if (video.dataset.fluxdmBound) return;
    video.dataset.fluxdmBound = "1";
    video.addEventListener("mouseenter", () => showForVideo(video));
    video.addEventListener("mousemove", () => {
      if (activeVideo !== video) showForVideo(video);
    });
    video.addEventListener("mouseleave", () => scheduleHide());
  }

  function scanVideos() {
    if (!enabled) return;
    document.querySelectorAll("video").forEach(attachToVideo);
  }

  chrome.storage.local.get({ showVideoOverlay: true }, (res) => {
    enabled = Boolean(res.showVideoOverlay);
    if (enabled) scanVideos();
  });

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.showVideoOverlay) {
      enabled = Boolean(changes.showVideoOverlay.newValue);
      if (!enabled && hostEl) {
        hostEl.style.display = "none";
      } else if (enabled) {
        scanVideos();
      }
    }
  });

  const observer = new MutationObserver(() => scanVideos());
  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  }
  window.addEventListener("scroll", () => activeVideo && positionOverlay(activeVideo), true);
  window.addEventListener("resize", () => activeVideo && positionOverlay(activeVideo));
  setInterval(scanVideos, 2500);
})();
