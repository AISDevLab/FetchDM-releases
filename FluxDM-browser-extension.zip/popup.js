const statusBadge = document.getElementById("status-badge");
const autoInterceptEl = document.getElementById("auto-intercept");
const showOverlayEl = document.getElementById("show-overlay");
const portEl = document.getElementById("bridge-port");
const savePortBtn = document.getElementById("save-port-btn");
const captureTabBtn = document.getElementById("capture-tab-btn");
const feedbackEl = document.getElementById("feedback");

function updateBadge(connected) {
  if (connected) {
    statusBadge.textContent = "Connected";
    statusBadge.className = "badge online";
  } else {
    statusBadge.textContent = "App Offline";
    statusBadge.className = "badge offline";
  }
}

async function refreshStatus() {
  const res = await chrome.runtime.sendMessage({ type: "GET_STATUS" });
  updateBadge(res.connected);
  autoInterceptEl.checked = res.config.autoIntercept;
  showOverlayEl.checked = res.config.showVideoOverlay;
  portEl.value = String(res.config.bridgePort);
}

autoInterceptEl.addEventListener("change", async () => {
  const res = await chrome.runtime.sendMessage({
    type: "SET_CONFIG",
    autoIntercept: autoInterceptEl.checked,
  });
  updateBadge(res.connected);
});

showOverlayEl.addEventListener("change", async () => {
  const res = await chrome.runtime.sendMessage({
    type: "SET_CONFIG",
    showVideoOverlay: showOverlayEl.checked,
  });
  updateBadge(res.connected);
});

savePortBtn.addEventListener("click", async () => {
  const port = Number(portEl.value) || 17890;
  const res = await chrome.runtime.sendMessage({
    type: "SET_CONFIG",
    bridgePort: port,
  });
  updateBadge(res.connected);
  feedbackEl.textContent = `Saved port ${port}.`;
});

captureTabBtn.addEventListener("click", async () => {
  feedbackEl.textContent = "Sending tab URL to FluxDM...";
  const res = await chrome.runtime.sendMessage({ type: "CAPTURE_CURRENT_TAB" });
  if (res?.ok) {
    feedbackEl.textContent = "Sent to FluxDM! Check the desktop app.";
  } else {
    feedbackEl.textContent = res?.error || "Could not reach FluxDM desktop app.";
  }
});

void refreshStatus();
