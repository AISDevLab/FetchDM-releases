const DEFAULT_CONFIG = {
  autoIntercept: true,
  showVideoOverlay: true,
  bridgePort: 17890,
};

async function getConfig() {
  const stored = await chrome.storage.local.get(DEFAULT_CONFIG);
  return {
    autoIntercept: Boolean(stored.autoIntercept),
    showVideoOverlay: Boolean(stored.showVideoOverlay),
    bridgePort: Number(stored.bridgePort) || 17890,
  };
}

async function checkBridgeHealth(port) {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1200);
    const resp = await fetch(`http://127.0.0.1:${port}/health`, {
      signal: controller.signal,
    });
    clearTimeout(timer);
    if (!resp.ok) return false;
    const data = await resp.json();
    return Boolean(data && data.ok);
  } catch {
    return false;
  }
}

async function sendToFetchDM(port, payload) {
  const resp = await fetch(`http://127.0.0.1:${port}/capture`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return resp.ok;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "fetchdm-link",
      title: "Download Link with FetchDM",
      contexts: ["link", "video", "audio"],
    });
    chrome.contextMenus.create({
      id: "fetchdm-page-media",
      title: "Download Page Video/Audio with FetchDM",
      contexts: ["page"],
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const cfg = await getConfig();
  if (info.menuItemId === "fetchdm-link") {
    const url = info.linkUrl || info.srcUrl;
    if (!url || (!url.startsWith("http://") && !url.startsWith("https://"))) return;
    const kind = info.mediaType === "video" || info.mediaType === "audio" ? "media" : null;
    await sendToFetchDM(cfg.bridgePort, {
      url,
      filename: null,
      referrer: info.pageUrl || tab?.url || null,
      kind,
    }).catch(() => {});
  } else if (info.menuItemId === "fetchdm-page-media") {
    const url = info.pageUrl || tab?.url;
    if (!url || (!url.startsWith("http://") && !url.startsWith("https://"))) return;
    await sendToFetchDM(cfg.bridgePort, {
      url,
      filename: null,
      referrer: url,
      kind: "media",
    }).catch(() => {});
  }
});

chrome.downloads.onCreated.addListener(async (downloadItem) => {
  const url = downloadItem.finalUrl || downloadItem.url;
  if (!url || (!url.startsWith("http://") && !url.startsWith("https://"))) {
    return;
  }
  const cfg = await getConfig();
  if (!cfg.autoIntercept) return;

  const alive = await checkBridgeHealth(cfg.bridgePort);
  if (!alive) return;

  try {
    await chrome.downloads.cancel(downloadItem.id);
    await chrome.downloads.erase({ id: downloadItem.id });
    await sendToFetchDM(cfg.bridgePort, {
      url,
      filename: downloadItem.filename || null,
      referrer: downloadItem.referrer || null,
      kind: "direct",
    });
  } catch {
    // Let browser handle download if cancel/hand-off failed
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    const cfg = await getConfig();
    if (message.type === "GET_STATUS") {
      const connected = await checkBridgeHealth(cfg.bridgePort);
      sendResponse({ connected, config: cfg });
    } else if (message.type === "SET_CONFIG") {
      const next = {
        autoIntercept:
          typeof message.autoIntercept === "boolean" ? message.autoIntercept : cfg.autoIntercept,
        showVideoOverlay:
          typeof message.showVideoOverlay === "boolean"
            ? message.showVideoOverlay
            : cfg.showVideoOverlay,
        bridgePort: Number(message.bridgePort) || cfg.bridgePort,
      };
      await chrome.storage.local.set(next);
      const connected = await checkBridgeHealth(next.bridgePort);
      sendResponse({ connected, config: next });
    } else if (message.type === "CAPTURE_VIDEO") {
      if (!message.url || (!message.url.startsWith("http://") && !message.url.startsWith("https://"))) {
        sendResponse({ ok: false });
        return;
      }
      const ok = await sendToFetchDM(cfg.bridgePort, {
        url: message.url,
        filename: null,
        referrer: message.referrer || null,
        kind: message.kind || "media",
      }).catch(() => false);
      sendResponse({ ok });
    } else if (message.type === "CAPTURE_CURRENT_TAB") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.url || (!tab.url.startsWith("http://") && !tab.url.startsWith("https://"))) {
        sendResponse({ ok: false, error: "Active tab does not have an HTTP/HTTPS URL" });
        return;
      }
      const ok = await sendToFetchDM(cfg.bridgePort, {
        url: tab.url,
        filename: null,
        referrer: tab.url,
        kind: "media",
      }).catch(() => false);
      sendResponse({ ok });
    }
  })();
  return true;
});
